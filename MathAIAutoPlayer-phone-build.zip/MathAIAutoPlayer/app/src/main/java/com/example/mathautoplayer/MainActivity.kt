package com.example.mathautoplayer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        val title = TextView(this).apply {
            text = "Math AI Auto Player"
            textSize = 25f
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "ตัวช่วยอ่านโจทย์คณิตศาสตร์และแตะตัวเลือกบนหน้าจอ\n\nวิธีใช้\n1) เปิดสิทธิ์ Accessibility ด้านล่าง\n2) เปิดบริการ Math AI Auto Player ในรายการบริการที่ดาวน์โหลด/ติดตั้ง\n3) กลับมาหน้านี้แล้วกดเริ่ม AI เล่น\n4) สลับไปเปิดเกมและค้างไว้ที่หน้าโจทย์\n5) กลับมาหน้านี้แล้วกดหยุด AI เมื่อต้องการหยุด\n\nระบบจะทำงานเมื่อพบโจทย์และตัวเลือกตัวเลข 4 ข้อที่อ่านได้ชัดเท่านั้น"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        status = TextView(this).apply {
            text = "สถานะ: ยังไม่เริ่ม"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, pad / 2, 0, pad)
        }
        val settings = Button(this).apply {
            text = "1. เปิดสิทธิ์ Accessibility"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "2. เริ่ม AI เล่น"
            setOnClickListener {
                getSharedPreferences("player", MODE_PRIVATE).edit().putBoolean("enabled", true).apply()
                status.text = "สถานะ: เปิดระบบแล้ว — สลับไปหน้าเกมได้เลย"
                Toast.makeText(this@MainActivity, "เปิดระบบแล้ว ให้สลับไปหน้าเกม", Toast.LENGTH_LONG).show()
            }
        }
        val stop = Button(this).apply {
            text = "หยุด AI"
            setOnClickListener {
                getSharedPreferences("player", MODE_PRIVATE).edit().putBoolean("enabled", false).apply()
                status.text = "สถานะ: หยุดแล้ว"
                Toast.makeText(this@MainActivity, "หยุดระบบแล้ว", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(status)
        layout.addView(settings)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            val prefs = getSharedPreferences("player", MODE_PRIVATE)
            val enabled = prefs.getBoolean("enabled", false)
            val detail = prefs.getString("status", "รอเปิด Accessibility")
            status.text = "สถานะ: ${if (enabled) "กำลังทำงาน" else "หยุดอยู่"}\n$detail"
        }
    }
}
