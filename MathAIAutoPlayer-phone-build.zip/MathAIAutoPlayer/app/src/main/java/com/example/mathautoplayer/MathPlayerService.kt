package com.example.mathautoplayer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.hardware.HardwareBuffer
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * On-device math-game helper. It only taps when it can read one expression and
 * exactly four numeric answer choices, with one unambiguous matching answer.
 */
class MathPlayerService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var busy = false
    private var lastTapAt = 0L
    private var lastQuestion = ""
    private var lastStatusAt = 0L

    private val loop = object : Runnable {
        override fun run() {
            val prefs = getSharedPreferences("player", MODE_PRIVATE)
            if (prefs.getBoolean("enabled", false) && !busy) captureAndSolve()
            handler.postDelayed(this, 800L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        setStatus("พร้อมทำงาน — เปิดเกมแล้วกดเริ่ม AI")
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* polling captures the visible game frame */ }

    override fun onInterrupt() {
        getSharedPreferences("player", MODE_PRIVATE).edit().putBoolean("enabled", false).apply()
        setStatus("หยุดทำงาน")
    }

    private fun captureAndSolve() {
        if (Build.VERSION.SDK_INT < 30) {
            setStatus("ต้องใช้ Android 11 ขึ้นไป")
            return
        }
        busy = true
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                var bitmap: Bitmap? = null
                try {
                    val buffer: HardwareBuffer = screenshot.hardwareBuffer
                    val wrapped = Bitmap.wrapHardwareBuffer(buffer, screenshot.colorSpace)
                    bitmap = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                    buffer.close()
                    wrapped?.recycle()
                    if (bitmap == null) {
                        busy = false
                        setStatus("อ่านภาพหน้าจอไม่ได้")
                        return
                    }
                    val frame = bitmap
                    recognizer.process(InputImage.fromBitmap(frame, 0))
                        .addOnSuccessListener { result -> analyzeAndTap(result, frame.width, frame.height) }
                        .addOnFailureListener { setStatus("OCR อ่านหน้าจอไม่สำเร็จ") }
                        .addOnCompleteListener {
                            frame.recycle()
                            busy = false
                        }
                } catch (_: Exception) {
                    bitmap?.recycle()
                    busy = false
                    setStatus("จับภาพหน้าจอไม่ได้ — ตรวจสอบสิทธิ์ Accessibility")
                }
            }

            override fun onFailure(errorCode: Int) {
                busy = false
                setStatus("จับภาพหน้าจอไม่สำเร็จ (รหัส $errorCode)")
            }
        })
    }

    private fun analyzeAndTap(result: Text, width: Int, height: Int) {
        val lines = result.textBlocks.flatMap { it.lines }
        val expressionRegex = Regex("(\\d+)\\s*[+＋*×xX÷/\\-]\\s*(\\d+)")
        val expressionLine = lines.firstOrNull { line ->
            line.boundingBox?.centerY()?.let { it in (height * 0.25).toInt()..(height * 0.72).toInt() } == true &&
                expressionRegex.containsMatchIn(line.text.replace("−", "-"))
        } ?: run {
            throttledStatus("กำลังมองหาโจทย์…")
            return
        }
        val expression = expressionLine.text.replace("−", "-").replace("＋", "+")
            .replace("×", "*").replace("÷", "/")
        val match = Regex("(\\d+)\\s*([+*xX/\\-])\\s*(\\d+)").find(expression)
            ?: run { throttledStatus("อ่านโจทย์ไม่ชัด") ; return }
        val a = match.groupValues[1].toLongOrNull() ?: return
        val op = match.groupValues[2]
        val b = match.groupValues[3].toLongOrNull() ?: return
        val answer = when (op) {
            "+" -> a + b
            "-" -> a - b
            "*", "x", "X" -> a * b
            "/" -> {
                if (b == 0L || a % b != 0L) return
                a / b
            }
            else -> return
        }

        val options = lines.mapNotNull { line ->
            val box = line.boundingBox ?: return@mapNotNull null
            if (box.centerY() < height * 0.56) return@mapNotNull null
            val value = line.text.trim().replace(",", "").replace(" ", "").toLongOrNull()
                ?: return@mapNotNull null
            value to box
        }.distinctBy { it.first to it.second.centerY() }

        // Avoid guessing if OCR sees too few/many values or an ambiguous match.
        if (options.size != 4) {
            throttledStatus("พบตัวเลือก ${options.size}/4 — รอภาพชัด")
            return
        }
        val matches = options.filter { it.first == answer }
        if (matches.size != 1) {
            throttledStatus("ยังยืนยันคำตอบไม่ได้")
            return
        }

        val chosen = matches.single().second
        val questionKey = "$a$op$b=$answer:${chosen.centerX()},${chosen.centerY()}"
        val now = System.currentTimeMillis()
        if (questionKey == lastQuestion && now - lastTapAt < 2500L) return
        lastQuestion = questionKey
        lastTapAt = now
        val tapped = tap(chosen.centerX().toFloat(), chosen.centerY().toFloat())
        setStatus(if (tapped) "แตะคำตอบ $answer แล้ว" else "ส่งคำสั่งแตะไม่สำเร็จ")
    }

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 65))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun throttledStatus(message: String) {
        val now = System.currentTimeMillis()
        if (now - lastStatusAt > 2500L) {
            lastStatusAt = now
            setStatus(message)
        }
    }

    private fun setStatus(message: String) {
        getSharedPreferences("player", MODE_PRIVATE).edit().putString("status", message).apply()
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        recognizer.close()
        super.onDestroy()
    }
}
